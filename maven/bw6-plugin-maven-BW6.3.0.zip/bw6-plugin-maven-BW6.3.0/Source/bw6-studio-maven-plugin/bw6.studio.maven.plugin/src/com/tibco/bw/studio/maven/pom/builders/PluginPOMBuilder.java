package com.tibco.bw.studio.maven.pom.builders;

import com.tibco.bw.studio.maven.modules.BWModule;
import com.tibco.bw.studio.maven.modules.BWProject;

public class PluginPOMBuilder extends ModulePOMBuilder
{

	@Override
	public void build(BWProject project, BWModule module) throws Exception {
		super.build(project, module);
	}

	
	
}
