package com.tibco.bw.studio.maven.modules;

public enum BWModuleType
{
	Parent, 
	Application,
	AppModule,
	SharedModule,
	PluginProject,
	CustomXPathProject
}
