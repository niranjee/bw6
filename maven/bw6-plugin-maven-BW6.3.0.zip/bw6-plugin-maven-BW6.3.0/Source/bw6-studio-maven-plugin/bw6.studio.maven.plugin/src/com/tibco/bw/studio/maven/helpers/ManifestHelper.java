package com.tibco.bw.studio.maven.helpers;

public class ManifestHelper {

}
