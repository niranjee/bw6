package com.tibco.bw.studio.maven.pom.builders;

public class SharedModulePOMBuilder extends ModulePOMBuilder
{

}
