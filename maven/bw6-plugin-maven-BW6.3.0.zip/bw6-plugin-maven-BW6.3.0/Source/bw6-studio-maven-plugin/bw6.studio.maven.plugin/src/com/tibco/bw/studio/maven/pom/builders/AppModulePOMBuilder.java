package com.tibco.bw.studio.maven.pom.builders;

public class AppModulePOMBuilder extends ModulePOMBuilder 
{

}
