package com.tibco.bw.maven.plugin.utils;

public interface Constants 
{

	public static final String ADMINEXEC = "bwadmin";
}
